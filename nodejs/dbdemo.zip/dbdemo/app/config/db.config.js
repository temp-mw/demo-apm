module.exports = {
  HOST: process.env.MYSQL_HOST,
  DB: "todo"
};